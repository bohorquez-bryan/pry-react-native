import React, {Component} from 'react';
import {StyleSheet, Text, View, Button} from 'react-native';
import moment from "moment";

export default class Page1 extends Component {

  constructor (props) {
     super(props);
     this.state = {
       actDate: new Date(),
       endDate: moment('2019-10-06'),
     };
   }

  render() {
     const today = this.state.actDate;
     const end = this.state.endDate;
     const datef = moment(end).format("LLL");
     const datea = moment(today).format("LLL");
     const dif = end.diff(datea,'days');
     const difh = end.diff(datea,'hours');

    return (
      <View style={styles.container}>
      <Text> Fecha actual: {datea} </Text>
       <Text> Fecha finalizacion: {datef} </Text>
       <Text> Faltan : {dif} dia(s) {difh} horas </Text>
      
      <Button title={'Ir a Página 2'} onPress={()=>this.props.navigation.navigate('Page2')}> </Button>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    
  },
  
});
